<?php
session_start();
include '../db_connect.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 0); // Set to 0 to prevent HTML errors in JSON response

header('Content-Type: application/json'); // Set content type to JSON

try {
    if(!isset($_SESSION['login_id'])) {
        throw new Exception("Unauthorized access");
    }

    // Get and sanitize form data
    $route_name = $conn->real_escape_string($_POST['route_name']);
    $start_location = (int)$_POST['start_location'];
    $stops = isset($_POST['stops']) ? $_POST['stops'] : [];
    $vehicle_type = $conn->real_escape_string($_POST['vehicle_type']);

    // Validate inputs
    if(empty($route_name) || empty($start_location) || empty($stops)) {
        throw new Exception("All fields are required");
    }

    // Get start location details
    $start_query = $conn->query("SELECT * FROM locations WHERE id = $start_location");
    if(!$start_query) {
        throw new Exception("Database error: " . $conn->error);
    }

    $start_data = $start_query->fetch_assoc();
    if(!$start_data) {
        throw new Exception("Start location not found");
    }

    // Initialize variables
    $total_distance = 0;
    $total_time = 0;
    $current_time = strtotime('08:00:00');
    $stops_with_eta = [];
    
    // Previous location starts as start point
    $prev_location = [
        'lat' => $start_data['latitude'],
        'lng' => $start_data['longitude']
    ];

    // Process each stop
    foreach($stops as $stop_id) {
        $stop_query = $conn->query("SELECT * FROM locations WHERE id = " . (int)$stop_id);
        $stop_data = $stop_query->fetch_assoc();
        
        if(!$stop_data) {
            continue;
        }

        // Calculate distance
        $distance = calculateDistance(
            $prev_location['lat'],
            $prev_location['lng'],
            $stop_data['latitude'],
            $stop_data['longitude']
        );

        $total_distance += $distance;
        
        // Calculate time (assume average speed of 40 km/h)
        $time_minutes = ($distance / 40) * 60;
        $total_time += $time_minutes;
        
        // Add stop time (15 minutes per stop)
        $current_time += ($time_minutes + 15) * 60;

        // Add to stops array
        $stops_with_eta[] = [
            'name' => $stop_data['name'],
            'eta' => date('H:i', $current_time)
        ];

        // Update previous location
        $prev_location = [
            'lat' => $stop_data['latitude'],
            'lng' => $stop_data['longitude']
        ];
    }

    // Save route to database
    $sql = "INSERT INTO routes (name, vehicle_type, start_location_id, created_by) 
            VALUES ('$route_name', '$vehicle_type', $start_location, {$_SESSION['login_id']})";
    
    if(!$conn->query($sql)) {
        throw new Exception("Error saving route: " . $conn->error);
    }
    
    $route_id = $conn->insert_id;

    // Prepare response
    $response = [
        'route_id' => $route_id,
        'start_location' => $start_data['name'],
        'stops' => $stops_with_eta,
        'totalDistance' => round($total_distance, 2),
        'estimatedTime' => round($total_time),
        'vehicle_type' => $vehicle_type
    ];

    echo json_encode($response);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}

// Helper function to calculate distance
function calculateDistance($lat1, $lon1, $lat2, $lon2) {
    $radius = 6371; // Earth's radius in kilometers
    
    $lat = deg2rad($lat2 - $lat1);
    $lon = deg2rad($lon2 - $lon1);
    
    $a = sin($lat/2) * sin($lat/2) + 
         cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * 
         sin($lon/2) * sin($lon/2);
    
    $c = 2 * atan2(sqrt($a), sqrt(1-$a));
    return $radius * $c;
}
?> 