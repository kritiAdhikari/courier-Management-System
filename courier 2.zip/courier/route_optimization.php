<?php 
// Add these debug lines at the top
error_reporting(E_ALL);
ini_set('display_errors', 1);

include('db_connect.php');
if(!isset($_SESSION['login_id'])) header('location:login.php');

// Add this after include('db_connect.php')
if(!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Test the locations query
$test_query = $conn->query("SELECT * FROM locations");
if(!$test_query) {
    die("Query failed: " . $conn->error);
}
?>

<!-- Add this to your <head> section or header.php -->
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<!-- Main Content -->
<div class="col-lg-12">
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Route Optimization</h3>
        </div>
        <div class="card-body">
            <div class="row">
                <!-- Form Section -->
                <div class="col-md-4">
                    <form id="routeForm">
                        <div class="form-group">
                            <label>Route Name</label>
                            <input type="text" class="form-control" name="route_name" required>
                        </div>
                        
                        <div class="form-group">
                            <label>Start Location</label>
                            <select class="form-control select2" name="start_location" required>
                                <option value="">Select Start Point</option>
                                <?php 
                                $locations = $conn->query("SELECT * FROM locations ORDER BY name ASC");
                                while($row = $locations->fetch_assoc()):
                                ?>
                                <option value="<?php echo $row['id'] ?>"><?php echo $row['name'] ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Select Stops</label>
                            <select class="form-control select2" name="stops[]" multiple required>
                                <?php 
                                $locations = $conn->query("SELECT * FROM locations ORDER BY name ASC");
                                while($row = $locations->fetch_assoc()):
                                ?>
                                <option value="<?php echo $row['id'] ?>"><?php echo $row['name'] ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Vehicle Type</label>
                            <select class="form-control" name="vehicle_type">
                                <option value="car">Car</option>
                                <option value="van">Van</option>
                                <option value="truck">Truck</option>
                            </select>
                        </div>

                        <button type="button" class="btn btn-primary" onclick="submitRoute()">
                            <i class="fa fa-route"></i> Optimize Route
                        </button>
                    </form>
                </div>

                <!-- Results Section -->
                <div class="col-md-8">
                    <div id="routeVisualization" class="border p-3">
                        <div class="text-center text-muted">
                            Route visualization will appear here
                        </div>
                    </div>
                    <div id="routeDetails" class="mt-3"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add the styles -->
<style>
.route-visual {
    background: #f8f9fa;
    border-radius: 5px;
    padding: 20px;
}

.route-stop {
    display: flex;
    align-items: center;
    background: white;
    padding: 15px;
    border-radius: 5px;
    margin: 10px 0;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.stop-number {
    font-size: 24px;
    margin-right: 15px;
    width: 40px;
    text-align: center;
}

.route-line {
    width: 2px;
    height: 20px;
    background: #007bff;
    margin-left: 19px;
}

.route-arrow {
    color: #007bff;
    margin-left: 15px;
    font-size: 20px;
}

.stop-details {
    flex-grow: 1;
}

.stop-details strong {
    display: block;
    font-size: 16px;
}

.stop-details .text-muted {
    font-size: 14px;
}
</style>

<!-- Add the JavaScript -->
<script src="https://www.gstatic.com/ai/generativelanguage/js/gemini.js"></script>
<script>
// Initialize Gemini
const API_KEY = 'AIzaSyD-Nywp7-56OdNRpIwcI2TMKcOPYRDxEP8'; // Replace with your API key
const genAI = new GoogleGenerativeAI(API_KEY);

$(document).ready(function(){
    // Initialize Select2
    $('.select2').select2({
        placeholder: "Select location(s)",
        width: '100%'
    });
});

function submitRoute() {
    // Show loading state
    $('#routeVisualization').html(`
        <div class="text-center p-5">
            <i class="fas fa-spinner fa-spin fa-2x"></i>
            <p class="mt-2">Optimizing route...</p>
        </div>
    `);

    // Get form data
    var formData = new FormData(document.getElementById('routeForm'));

    // Send AJAX request
    $.ajax({
        url: 'ajax/route_optimizer.php',
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function(response) {
            console.log('Response:', response);
            try {
                let data = typeof response === 'string' ? JSON.parse(response) : response;
                displayRouteResults(data);
            } catch(error) {
                console.error('Error:', error);
                alert('Error processing response');
            }
        },
        error: function(xhr, status, error) {
            console.error('AJAX Error:', error);
            alert('Error optimizing route: ' + error);
        }
    });
}

function displayRouteResults(data) {
    // Create route visualization
    let visualHtml = `
        <div class="route-visual">
            <h5 class="mb-4">Route Sequence</h5>
            
            <!-- Start Point -->
            <div class="route-stop">
                <div class="stop-number">⭐</div>
                <div class="stop-details">
                    <strong>${data.start_location}</strong>
                    <span class="text-muted">Starting Point - 8:00 AM</span>
                </div>
            </div>
            <div class="route-line"></div>
            <div class="route-arrow">↓</div>
    `;

    // Add each stop
    const emojis = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'];
    data.stops.forEach((stop, index) => {
        visualHtml += `
            <div class="route-stop">
                <div class="stop-number">${emojis[index]}</div>
                <div class="stop-details">
                    <strong>${stop.name}</strong>
                    <span class="text-muted">ETA: ${stop.eta}</span>
                </div>
            </div>
            ${index < data.stops.length - 1 ? '<div class="route-line"></div><div class="route-arrow">↓</div>' : ''}
        `;
    });

    visualHtml += `</div>`;

    // Create route details
    let detailsHtml = `
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Route Analysis</h5>
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>Total Distance:</strong> ${data.totalDistance} km</p>
                        <p><strong>Estimated Time:</strong> ${data.estimatedTime} mins</p>
                        <p><strong>Vehicle Type:</strong> ${data.vehicle_type}</p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Total Stops:</strong> ${data.stops.length}</p>
                        <p><strong>Start Location:</strong> ${data.start_location}</p>
                        <p><strong>Route ID:</strong> ${data.route_id}</p>
                    </div>
                </div>
            </div>
        </div>
    `;

    // Update the DOM
    $('#routeVisualization').html(visualHtml);
    $('#routeDetails').html(detailsHtml);
}

// Prevent dashboard2.js canvas error
$(document).ready(function() {
    // Create dummy canvas if it doesn't exist
    if (!document.getElementById('line-chart')) {
        $('<canvas>').attr({
            id: 'line-chart',
            style: 'display: none'
        }).appendTo('body');
    }
    
    if (!document.getElementById('sales-chart')) {
        $('<canvas>').attr({
            id: 'sales-chart',
            style: 'display: none'
        }).appendTo('body');
    }
    
    if (!document.getElementById('visitors-chart')) {
        $('<canvas>').attr({
            id: 'visitors-chart',
            style: 'display: none'
        }).appendTo('body');
    }
});
</script>

<!-- Add this somewhere in your page -->
<div style="display: none;">
    <canvas id="line-chart"></canvas>
    <canvas id="sales-chart"></canvas>
    <canvas id="visitors-chart"></canvas>
</div> 