// Remove these event handlers if they exist
$('select[name="algorithm"]').change(function(){
    // ... scheduling code ...
});

$('#schedule-form').submit(function(e){
    // ... scheduling code ...
}); 