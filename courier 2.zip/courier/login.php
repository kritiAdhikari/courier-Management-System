<!DOCTYPE html>
<html lang="en">
<?php 
session_start();
include('./db_connect.php');
ob_start();
$system = $conn->query("SELECT * FROM system_settings")->fetch_array();
foreach($system as $k => $v){
    $_SESSION['system'][$k] = $v;
}
ob_end_flush();

if(isset($_SESSION['login_id']))
    header("location:index.php?page=home");
?>
<?php include 'header.php' ?>
<body>
    <div class="container-fluid">
        <div class="row min-vh-100">
            <!-- Left side with illustration -->
            <div class="col-md-6 bg-white p-5 d-flex flex-column justify-content-center">
                <img src="assets/img/deliveri-logo.png" alt="Deliveri" class="mb-3" style="max-width: 400px;">
                <h2 class="mb-2">Welcome back!</h2>
                <p class="text-muted">Experience the Powerful Courier Management Software</p>
                <p class="text-muted small">By Hira lal Shrestha <br> Pratima Das<br>Kriti Adhikari</p>
                
                <!-- Add your illustration image here -->
                <img src="assets/img/courier-illustration1.jpg" alt="Courier Management" class="img-fluid mt-4" style="max-width: 400px;">
            </div>

            <!-- Right side with login form -->
            <div class="col-md-6 bg-light p-5 d-flex align-items-center">
                <div class="login-form w-100 max-w-400">
                    <h4 class="text-end mb-4">Courier Management System - Authority Login</h4>
                    
                    <form action="" id="login-form">
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" name="email" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" name="password" required>
                        </div>
                        
                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" id="remember">
                            <label class="form-check-label" for="remember">Remember my preference</label>
                        </div>
                        
                        <button type="submit" class="btn btn-primary w-100" style="background-color: #1a237e;">Sign In</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <style>
        .max-w-400 {
            max-width: 400px;
            margin: 0 auto;
        }
        .form-control {
            padding: 0.75rem 1rem;
            border-radius: 8px;
        }
        .btn-primary {
            padding: 0.75rem;
            border-radius: 8px;
            font-weight: 500;
        }
        body {
            background-color: #f5f5f5;
        }
    </style>

    <script>
        $(document).ready(function(){
            $('#login-form').submit(function(e){
                e.preventDefault()
                start_load()
                if($(this).find('.alert-danger').length > 0 )
                    $(this).find('.alert-danger').remove();
                $.ajax({
                    url:'ajax.php?action=login',
                    method:'POST',
                    data:$(this).serialize(),
                    error:err=>{
                        console.log(err)
                        end_load();
                    },
                    success:function(resp){
                        if(resp == 1){
                            location.href ='index.php?page=home';
                        }else{
                            $('#login-form').prepend('<div class="alert alert-danger">Username or password is incorrect.</div>')
                            end_load();
                        }
                    }
                })
            })
        })
    </script>
    <?php include 'footer.php' ?>
</body>
</html>
